#include<stdio.h>
main(){

    int num1 , num2 , mult;
    printf("Digite as medidas da sala: ");
        scanf("%d %d" , &num1 , &num2);

        mult = num1 * num2;

        printf("A area da sua sala e: %d\n" , mult);



}