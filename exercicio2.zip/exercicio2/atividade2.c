#include<stdio.h>
main(){

 int num1 , num2 = 2 , mult  ;
  printf("Digite um numero: ");
        scanf("%d" , &num1  );

        mult = num1 * num2;

        printf("O dobro do seu numero e: %d\n" , mult);


}