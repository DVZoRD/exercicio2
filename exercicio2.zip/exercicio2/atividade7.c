#include<stdio.h>
main(){

int raio , num1 = 2,  area;


 printf ("Digite o raio do circulo: ");
        scanf("%d" , &raio ); 

  area =  pow(raio,num1) * 3.14;

printf("A area do seu circulo e: %d", area);





}